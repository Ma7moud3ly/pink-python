#Factorial
Factorial has magic functions to calculate the factorial of any numbers ^_^